"""Offline booklet imposition."""
